<?php
class openstock{
    function __construct(){
        $this->addonName        = 'OpenStock - variant stock control';
        $this->addonVersion     = '150';
    }
}
?>
