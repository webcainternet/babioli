<?php
$_['text_out_of_stock']     = 'Out of stock!';
$_['text_in_stock']         = '%s item(s) in stock';
$_['text_in_stock_avail']   = 'In stock';
$_['combination_not_avail'] = 'Option choice not available';
$_['text_id_missing']       = 'Bad request';
$_['text_checking_options'] = 'Checking status';
$_['text_discount']         = ' or more ';
$_['text_nodiscount']       = 'No quantity discount available';