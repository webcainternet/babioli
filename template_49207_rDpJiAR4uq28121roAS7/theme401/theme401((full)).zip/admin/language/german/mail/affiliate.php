<?php
// Text
$_['text_approve_subject']      = '%s - Ihr Partnerkonto wurde aktiviert!';
$_['text_approve_welcome']      = 'Herzlich Willkommen und danke für die Registrierung bei %s!';
$_['text_approve_login']        = 'Ihr Konto wurde erstellt. Sie können sich jetzt mit Ihrer E-Mail Adresse und dem Passwort auf unserer Website anmelden:';
$_['text_approve_services']     = 'Nach der Anmeldung können Sie Tracking Codes erzeugen, Provisionszahlungen verfolgen und Kontoinformationen ändern.';
$_['text_approve_thanks']       = 'Danke,';
$_['text_transaction_subject']  = '%s - Partnerprovision';
$_['text_transaction_received'] = 'Sie haben Provision in Höhe von %s erhalten!';
$_['text_transaction_total']    = 'Ihre gesamte Provision beträgt nun %s.';
?>