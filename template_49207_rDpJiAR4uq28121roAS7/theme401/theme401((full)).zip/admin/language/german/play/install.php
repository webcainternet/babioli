<?php
$_['heading_title']                     = 'Play.com (Europe)';
$_['text_edit']                         = 'Bearbeiten';
$_['text_install']                      = 'Installieren';
$_['text_uninstall']                    = 'Deinstallieren';
$_['text_enabled']                      = 'Aktiviert';
$_['text_disabled']                     = 'Deaktiviert';
$_['lang_text_success']                 = 'Sie haben Ihre Änderungen im Play.com Modul gespeichert.';
?>