<?php
$_['lang_title']                    = 'OpenBay Pro für Amazon';
$_['lang_heading']                  = 'Amazon Überblick';
$_['lang_overview']                 = 'Amazon Überblick';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Einstellungen';
$_['lang_heading_account']          = 'Mein Konto';
$_['lang_heading_links']            = 'verbundene Artikel';
$_['lang_heading_register']         = 'Anmelden';
$_['lang_heading_stock_updates']    = 'Lagerbestandsänderungen';
$_['lang_heading_saved_listings']   = 'gespeicherte Angebote';
?>