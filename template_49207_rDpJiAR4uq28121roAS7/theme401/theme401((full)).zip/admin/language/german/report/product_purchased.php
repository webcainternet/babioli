<?php
// Heading
$_['heading_title']     = 'Gekaufte Produkte';

//Text
$_['text_all_status']   = 'Alle Stati';

// Column
$_['column_date_start'] = 'Startdatum';
$_['column_date_end']   = 'Ablaufdatum';
$_['column_name']       = 'Bezeichnung';
$_['column_model']      = 'Modell';
$_['column_quantity']   = 'Menge';
$_['column_total']      = 'Summe';

//Entry
$_['entry_date_start']  = 'Startdatum:';
$_['entry_date_end']    = 'Ablaufdatum:';
$_['entry_status']      = 'Auftragsstatus:';
?>