<?php
// Heading
$_['heading_title']    = 'Total';

// Text
$_['text_total']       = 'Totales del pedid';
$_['text_success']     = 'Éxito: has modificado los totales!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el total!';
?>
