<?php
// Heading
$_['heading_title']    = 'Crédito de la tienda';

// Text
$_['text_total']       = 'Totales del pedido';
$_['text_success']     = 'SÉxito: has modificado el total del crédito en la tienda!!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el total de crédito en la tienda!!';
?>