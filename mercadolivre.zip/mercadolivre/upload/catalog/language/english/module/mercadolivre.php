<?php
// Text
$_['text_home']           = 'Home';
$_['text_title']           = 'Mercadolivre Authentication';
$_['heading_title']           = 'Mercadolivre Authentication';
$_['text_intro']                      = 'Authentication your mercadolivre account with opencart. Just click the following link to start';
$_['text_auth']                      = 'Authenticate Mercadolivre';
$_['text_auth_done']                      = 'Your authentication already done.';
$_['text_reauth']                      = 'Re-authenticate to Mercadolivre';


?>